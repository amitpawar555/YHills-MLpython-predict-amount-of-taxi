# taxi_fare-prediction
This is a regression model used to predict the fare price amount(inclusive of tolls) for a taxi ride, given the pickup and dropoff locations,the pickup date time and many other attributes given below.
